## cs207-FinalProject
### Group 20
Emily Batt,
Duo Zhang,
Evan Simons.

Travis CI
[![Build Status](https://travis-ci.com/JEE-dream-team/cs207-FinalProject.svg?branch=master)](https://travis-ci.com/JEE-dream-team/cs207-FinalProject)

CodeCov
[![codecov](https://codecov.io/gh/JEE-dream-team/cs207-FinalProject/branch/master/graph/badge.svg)](https://codecov.io/gh/JEE-dream-team/cs207-FinalProject)